//--------------------------------------------------------------------
//
//  Laboratory 13                                             heap.cpp
//  
//  ����: ��ǻ�Ͱ�������
//  �й�: 2021110488
//  �̸�: �̰ǿ�
//  
//  Actual implementation of class in the Heap ADT
//--------------------------------------------------------------------

#include "heap.h"

//--------------------------------------------------------------------


template<class DT>
Heap<DT>::Heap(int maxNumber)
{
	maxSize = maxNumber;
	size = 0;
	dataItems = new DT[maxSize];
}

template < class DT >
Heap<DT>::~Heap()
{
	clear();
	// deallocate
	delete[] dataItems;
}

//--------------------------------------------------------------------

template < class DT >
void Heap<DT>::insert(const DT& newDataItem)
{
	if (isEmpty())
	{
		dataItems[size++] = newDataItem;
		return;
	}
	else if (!isFull())
	{
		// ���ο� ������ �߰�
		dataItems[size] = newDataItem;

		// ������ ������ �ε���
		int newIndex = size++;
		// ������ ������ �θ� ���
		int parent = (newIndex - 1) / 2;

		while (newIndex > 0 && dataItems[parent].pty() < dataItems[newIndex].pty())
		{
			// Swap
			DT temp = dataItems[parent];
			dataItems[parent] = dataItems[newIndex];
			dataItems[newIndex] = temp;

			newIndex = parent;
			parent = (newIndex - 1) / 2;
		}
	}
	else
	{
		cout << "Heap is full" << endl;
	}
}

template < class DT >
DT Heap<DT>::removeMax()
{
	if (!isEmpty())
	{
		DT popedItem = dataItems[0];
		DT temp = dataItems[--size];
		
		int child = 1;
		int parent = 0;
		child = 1;

		dataItems[0] = temp;

		while (child < size)
		{
			if (child + 1 == size)
			{

			}
			else if (child < size && dataItems[child].pty() < dataItems[child + 1].pty())
			{
				child++;
			}

			if (dataItems[parent].pty() > dataItems[child].pty())
			{
				break;
			}

			// swap
			temp = dataItems[parent];
			dataItems[parent] = dataItems[child];
			dataItems[child] = temp;

			parent = child;
			child <<= 1;	// ���ϱ� 2
		}

		dataItems[parent] = temp;

		return popedItem;
	}
	else // heap is Empty
	{
		DT null;
		null.setPty(NULL);
		cout << "Heap is Empty" << endl;
		return null;
	}
}

template < class DT >
void Heap<DT>::clear()
{
	size = 0;
}

//--------------------------------------------------------------------

template < class DT >
bool Heap<DT>::isEmpty() const
{
	if (size == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

template < class DT >
bool Heap<DT>::isFull() const
{
	if (size >= maxSize)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//--------------------------------------------------------------------

template < class DT >
void Heap<DT>::showStructure() const
// Outputs the priorities of the data in a heap in both array
// and tree form. If the heap is empty, outputs "Empty heap". This
// operation is intended for testing/debugging purposes only.
{
	int j;   // Loop counter

	cout << endl;
	if (size == 0)
		cout << "Empty heap" << endl;
	else
	{
		cout << "size = " << size << endl;       // Output array form
		for (j = 0; j < maxSize; j++)
			cout << j << "\t";
		cout << endl;
		for (j = 0; j < size; j++)
			cout << dataItems[j].pty() << "\t";
		cout << endl << endl;
		showSubtree(0, 0);                        // Output tree form
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < class DT >
void Heap<DT>::showSubtree(int index, int level) const

// Recursive partner of the showStructure() function. Outputs the
// subtree (subheap) whose root is stored in dataItems[index]. Argument
// level is the level of this dataItems within the tree.

{
	int j;   // Loop counter

	if (index < size)
	{
		showSubtree(2 * index + 2, level + 1);        // Output right subtree
		for (j = 0; j < level; j++)        // Tab over to level
			cout << "\t";
		cout << " " << dataItems[index].pty();   // Output dataItems's pty
		if (2 * index + 2 < size)                // Output "connector"
			cout << "<";
		else if (2 * index + 1 < size)
			cout << "\\";
		cout << endl;
		showSubtree(2 * index + 1, level + 1);        // Output left subtree
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < class DT >
void Heap<DT>::writeLevels() const
{
	int level = 1;
	int count = 0;
	
	while (count < size)
	{
		for (int i = 0; i < level; i++)
		{
			cout << dataItems[count++].pty() << ' ';
			if (count == size) 
			{
				break;
			}
		}
		level <<= 1;
		cout << '\n';
	}
}
