//--------------------------------------------------------------------
//
//  Laboratory B, In-lab Exercise 2                     heapsort.cpp
//
//   heapSort() function
//
//   ����: ��ǻ�Ͱ�������
//   �й�: 2021110488
//   �̸�: �̰ǿ�
// 
//--------------------------------------------------------------------

template < class DT >
void moveDown(DT dataItem[], int root, int size)

// Restores the binary tree that is rooted at root to a heap by moving
// dataItem[root] downward until the tree satisfies the heap property.
// Parameter size is the number of data items in the array.

{
	int child = root * 2 + 1;

	while (child < size)
	{
		if (child + 1 == size)
		{
			// do nothing (child�� �״��)
		}
		else if (dataItem[child].pty() < dataItem[child + 1].pty())
		{
			child++;
		}

		if (dataItem[root].pty() > dataItem[child].pty())
		{
			break;
		}

		// swap
		DT temp = dataItem[root];
		dataItem[root] = dataItem[child];
		dataItem[child] = temp;

		root = child;
		child = root * 2 + 1;	// ���ϱ� 2
	}
}

//--------------------------------------------------------------------

template < class DT >
void heapSort(DT dataItem[], int size)

// Heap sort routine. Sorts the data items in the array in ascending
// order based on priority.

{
	DT temp;   // Temporary storage
	int j;     // Loop counter

	// Build successively larger heaps within the array until the
	// entire array is a heap.

	for (j = (size - 1) / 2; j >= 0; j--)
		moveDown(dataItem, j, size);

	// Swap the root data item from each successively smaller heap with
	// the last unsorted data item in the array. Restore the heap after
	// each exchange.

	for (j = size - 1; j > 0; j--)
	{
		temp = dataItem[j];
		dataItem[j] = dataItem[0];
		dataItem[0] = temp;
		moveDown(dataItem, 0, j);
	}
}

